typedef enum
{
  FLICKER_TAG_VERSION

} eFLKRTag;
