typedef enum
{
    MF_TAG_VERSION

} eMFTag;
