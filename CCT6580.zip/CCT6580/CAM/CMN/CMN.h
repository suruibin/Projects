typedef enum
{

} eCMNTag;