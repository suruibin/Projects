typedef enum
{

} eAFTag;