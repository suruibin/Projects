typedef enum
{
    CMN_TAG_VERSION,
    CMN_SHOT_MODE,
    CMN_CAM_MODE,
} eCMNTag;
